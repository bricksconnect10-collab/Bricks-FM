$ErrorActionPreference = "Stop"

$AppName = "BRICKS FM"
$SourceDir = $PSScriptRoot
$InstallDir = Join-Path $env:LOCALAPPDATA "BRICKS_FM"

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

# Copy bundled offline web app & launcher files
foreach ($File in @("bricks_fm.ico", "Launch_BRICKS_FM.ps1", "BRICKS_FM.vbs")) {
    $Src = Join-Path $SourceDir $File
    if (Test-Path $Src) {
        Copy-Item -Force $Src (Join-Path $InstallDir $File)
    }
}

$DistSrc = Join-Path $SourceDir "dist"
$DistDest = Join-Path $InstallDir "dist"
if (Test-Path $DistSrc) {
    if (Test-Path $DistDest) { Remove-Item -Recurse -Force $DistDest }
    Copy-Item -Recurse -Force $DistSrc $DistDest
}

$WshShell = New-Object -ComObject WScript.Shell
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$StartMenuDir = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
$VbsPath = Join-Path $InstallDir "BRICKS_FM.vbs"
$IconPath = Join-Path $InstallDir "bricks_fm.ico"

foreach ($TargetDir in @($DesktopPath, $StartMenuDir)) {
    $ShortcutPath = Join-Path $TargetDir "$AppName.lnk"
    $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = "$env:SystemRoot\System32\wscript.exe"
    $Shortcut.Arguments = "`"$VbsPath`""
    $Shortcut.WorkingDirectory = $InstallDir
    $Shortcut.Description = "BRICKS FM - Books, Stories & Audiobooks"
    if (Test-Path $IconPath) {
        $Shortcut.IconLocation = "$IconPath,0"
    }
    $Shortcut.Save()
}

Write-Host "BRICKS FM installed to Desktop and Start Menu!" -ForegroundColor Green
Start-Process "$env:SystemRoot\System32\wscript.exe" "`"$VbsPath`""
