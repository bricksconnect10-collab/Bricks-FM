BRICKS FM - Windows Desktop Package
====================================

OPTION 1: Instant 1-Click Windows App Install (No Node.js needed)
1. Extract this ZIP folder anywhere.
2. Double-click "Install_BRICKS_FM_Windows.bat".
3. It creates "BRICKS FM" shortcuts on your Windows Desktop and Start Menu
   with the official BRICKS FM icon and launches in a standalone app window!

OPTION 2: Build Offline Windows .exe Installer (BRICKS-FM-Setup.exe)
Requirements: Node.js 20+
1. From the main project root:
   npm install
   npm run build
2. Inside the desktop/ folder:
   cd desktop
   npm install
   npm run dist:win
3. Your installer (BRICKS-FM-nsis-x64.exe) and portable app
   (BRICKS-FM-portable-x64.exe) will appear in release-win/.
