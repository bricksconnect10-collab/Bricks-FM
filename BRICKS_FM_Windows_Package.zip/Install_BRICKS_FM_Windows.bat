@echo off
title BRICKS FM - Windows App Installer
echo ============================================
echo   Installing BRICKS FM on Windows PC...
echo ============================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install_BRICKS_FM_Windows.ps1"
if %ERRORLEVEL% NEQ 0 (
  echo.
  echo Installation encountered an error. Check README_WINDOWS.txt for Node.js EXE option.
  pause
  exit /b 1
)
echo.
echo Installed! Launching BRICKS FM now...
timeout /t 2 >nul
