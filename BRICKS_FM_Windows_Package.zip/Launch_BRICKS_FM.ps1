$ErrorActionPreference = "SilentlyContinue"
$InstallDir = $PSScriptRoot
$DistDir = Join-Path $InstallDir "dist"
$Port = 4173
$LocalUrl = "http://127.0.0.1:$Port/"

$BrowserPaths = @(
    "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles (x86)\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$BrowserExe = $BrowserPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not (Test-Path (Join-Path $DistDir "index.html"))) {
    if ($BrowserExe) {
        Start-Process $BrowserExe "--app=https://ais-pre-5ywmfqusjzuaq2ekhew4dt-994113635464.asia-southeast1.run.app --window-size=480,860"
    }
    exit 0
}

# Check if local server is already listening on port
$AlreadyRunning = $false
try {
    $tcp = New-Object System.Net.Sockets.TcpClient("127.0.0.1", $Port)
    $tcp.Close()
    $AlreadyRunning = $true
} catch {
    $AlreadyRunning = $false
}

if ($AlreadyRunning) {
    if ($BrowserExe) {
        Start-Process $BrowserExe "--app=$LocalUrl --window-size=480,860"
    } else {
        Start-Process $LocalUrl
    }
    exit 0
}

$Listener = New-Object System.Net.HttpListener
$Listener.Prefixes.Add($LocalUrl)
$Listener.Start()

if ($BrowserExe) {
    Start-Process $BrowserExe "--app=$LocalUrl --window-size=480,860"
} else {
    Start-Process $LocalUrl
}

$MimeMap = @{
    ".html" = "text/html; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".mjs"  = "application/javascript; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".webmanifest" = "application/manifest+json; charset=utf-8"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
    ".webp" = "image/webp"
    ".woff2"= "font/woff2"
}

$LastActivity = Get-Date
while ($Listener.IsListening) {
    $ContextTask = $Listener.GetContextAsync()
    while (-not $ContextTask.AsyncWaitHandle.WaitOne(1000)) {
        if (((Get-Date) - $LastActivity).TotalMinutes -gt 120) {
            $Listener.Stop()
            exit 0
        }
    }
    $LastActivity = Get-Date
    $Ctx = $ContextTask.GetAwaiter().GetResult()
    $RelPath = $Ctx.Request.Url.AbsolutePath.TrimStart("/")
    if ([string]::IsNullOrWhiteSpace($RelPath)) { $RelPath = "index.html" }
    $FullPath = Join-Path $DistDir ($RelPath -replace "/", "\")
    if (-not (Test-Path $FullPath -PathType Leaf)) {
        $FullPath = Join-Path $DistDir "index.html"
    }
    $Ext = [System.IO.Path]::GetExtension($FullPath).ToLower()
    $Ctx.Response.ContentType = if ($MimeMap.ContainsKey($Ext)) { $MimeMap[$Ext] } else { "application/octet-stream" }
    $Bytes = [System.IO.File]::ReadAllBytes($FullPath)
    $Ctx.Response.ContentLength64 = $Bytes.Length
    $Ctx.Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
    $Ctx.Response.OutputStream.Close()
}
